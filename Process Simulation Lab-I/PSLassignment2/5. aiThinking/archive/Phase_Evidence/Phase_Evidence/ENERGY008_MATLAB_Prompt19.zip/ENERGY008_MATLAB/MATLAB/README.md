# ENERGY-008 MATLAB Engine (Prompt 19)

Run `START_HERE.m` from MATLAB. The startup script resolves the project root from its own full path and the `.energy008-root` marker. It sets only the controlled `MATLAB/` source folder on the MATLAB path. It verifies the project manifest and SHA-256 integrity before loading the versioned JSON inputs.

Prompt 19 implements the ideal stoichiometric reference calculation, selected pure-component property reference correlations, reference enthalpy rates, two Prompt 17 screening relations, DB-059 shortfall arithmetic, scenario status propagation, source-gated environmental KPIs and source-gated CAPEX/OPEX/LCOM screening equations. Missing process data do not become zero. Plant-level PFR kinetics, PR78 flash, methanol-water VLE, physical S-209 recycle/S-207 purge, actual utilities, plant energy/entropy/exergy closure, and current project economics remain explicitly blocked.

## Run and test

After `START_HERE.m` completes, use the root-level test wrapper:

```matlab
report = run_prompt19_tests(ENERGY008_PROJECT_ROOT);
```

For the startup/relocation smoke test, execute the controlled test script by its full project-relative path:

```matlab
run(fullfile(ENERGY008_PROJECT_ROOT, 'MATLAB', 'tests', 'run_startup_smoke_test.m'));
```

The root-level test wrapper temporarily adds only `MATLAB/tests/` and restores the original path immediately after the suite. Normal startup does not add the tests folder. SHA-256 integrity verification requires a JVM-enabled MATLAB session; no minimum release or add-on toolbox availability has been verified.

See `docs/Model_Implementation.md`, `docs/PROMPT19_BUILD_REPORT.md` and `docs/Prompt20_Handoff.md` for equations, units, scope, known blockers and next steps. The engine is not a validated plant simulation. Prompt 21 independent verification and validation remain mandatory.

**Runtime caveat:** MATLAB/Octave execution was unavailable during this build. MATLAB release compatibility, the JVM feature and workbook inspection API must be verified on the target MATLAB installation. SHA-256 verification requires an enabled MATLAB JVM. No add-on toolbox is declared as a verified dependency.
