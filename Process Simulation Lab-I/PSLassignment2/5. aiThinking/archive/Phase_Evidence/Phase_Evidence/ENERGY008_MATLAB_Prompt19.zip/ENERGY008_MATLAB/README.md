# ENERGY-008 MATLAB Project

Prompt 18 architecture plus the Prompt 19 executable reference calculation engine. Open `MATLAB/START_HERE.m` in MATLAB and run it. The project root is resolved from the startup file and project marker, not the current working directory.

The supported reference engine reproduces the ideal Prompt 17 stoichiometric fixture and runs bounded screening calculations where source data permit. Physical plant calculations remain explicitly blocked where validated inputs/models are missing. See `MATLAB/docs/Model_Implementation.md` and `MATLAB/docs/PROMPT19_BUILD_REPORT.md`.

MATLAB/Octave runtime was unavailable during this build: runtime status is `NOT RUN`. SHA-256 startup verification requires a JVM-enabled MATLAB session. The target MATLAB release and toolbox availability must be established by executing the included tests.

The Prompt 19 throughput sensitivity plan is stored at `MATLAB/data/sensitivity_plan_v0.1.0.json` and is loaded through the explicit project configuration and manifest.
