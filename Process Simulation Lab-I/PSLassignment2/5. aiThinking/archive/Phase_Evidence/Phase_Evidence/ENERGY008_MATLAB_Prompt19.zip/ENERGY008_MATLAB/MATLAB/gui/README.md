# GUI layer boundary

The GUI folder is intentionally not added to the MATLAB path by default. Prompt 19 or a later GUI phase may add explicitly selected GUI source folders after validating their dependencies.

GUI callbacks must only collect user inputs, build/modify a canonical `modelInput`/`request` structure, invoke the public engine entry point, and render returned `ModuleResult`/`Diagnostic` structures. No material-balance, property, energy, sizing, economic, optimisation or control calculation belongs in a callback.

Use the same schema IDs and data-status semantics as the calculation engine. GUI field validation is a usability layer, not a substitute for `input_validation.m`.
