# ENERGY-008 Engineering Model and MATLAB GUI

This project contains the Prompt 18 architecture, Prompt 19 reference calculation engine, and Prompt 20 programmatic MATLAB engineering GUI.

## Launch

- **Engineering GUI:** In MATLAB, navigate into the project's `MATLAB/` subfolder and run `app = run_gui;`.
- **Engine startup / command-line workflow:** Open and run `MATLAB/START_HERE.m` as described in `MATLAB/README.md`.

The GUI launcher resolves the project root from its own file path and the `.energy008-root` marker. It adds only the configured `MATLAB/` engine folder and `MATLAB/gui/` UI folder. The callbacks delegate calculations to the Prompt 19 engine modules.

## Model scope

Route C remains a provisional working basis and G3 Rev 0.1-DRAFT is not frozen. The 50 t/day Route C case is an illustrative ideal stoichiometric reference, not an approved plant nameplate capacity. The GUI's Streams table presents calculated stoichiometric component/ledger references, not 55 solved physical PFD stream states.

Physical PFR kinetics, PR78 flash, methanol-water VLE, physical S-209 recycle/S-207 purge, plant energy/entropy/exergy closure, actual utility demand, environmental MRV/certification, and CAPEX/OPEX/LCOM remain blocked where source/model data are incomplete. The Automation & Control tab is read-only; it is not a live DCS/PLC/SIS/FGS application and has no field command path.

## Verification status

The Prompt 19/20 source-integrity checks and independent arithmetic audit are documented in `21_Verification/`. These are static/Python checks only. An earlier static-check revision exposed stale Prompt 18/Prompt 19 architecture expectations and configuration mismatches; the corrected source checker and startup contract are retained with the defect log.

MATLAB and GNU Octave are unavailable in the build environment. The GUI has not been launched, MATLAB syntax and target-release compatibility have not been verified, no actual GUI screenshots exist, and no MATLAB-generated example exports are included. Follow `MATLAB/docs/GUI_User_Guide.md` and `MATLAB/docs/Prompt21_GUI_Handoff.md` for the required runtime and independent verification procedure.

## Prompt 23 | staged Python migration

A GUI-independent Python migration is included in `Python/`. It ports only the source-supported reference/screening calculation boundary and retains explicit BLOCKED results for unsupported physical models. It uses NumPy, SciPy, pandas and Matplotlib; CoolProp, Cantera, BioSTEAM and DWSIM are assessed but not bundled or silently substituted.

- Python package and source: `Python/src/energy008/`
- Clean install and run instructions: `Python/README.md`
- Pinned environment: `Python/requirements.lock` (CPython 3.13.5 Linux test environment)
- Mapping workbook: `Python/docs/MATLAB_to_Python_Mapping.xlsx`
- Python runtime evidence: `Python/docs/Python_Test_and_Parity_Report.md`
- Actual CLI outputs: `Python/results/`
- Prompt 24 handoff: `Python/docs/Prompt24_Handoff.md`

Latest Python test run: 23 passed. Python-to-frozen-hand-fixture reference parity passed within fixture tolerances. MATLAB-to-Python runtime parity remains NOT RUN because MATLAB/Octave execution evidence was unavailable. This is a partial migration, not a validated full-process Python model.
