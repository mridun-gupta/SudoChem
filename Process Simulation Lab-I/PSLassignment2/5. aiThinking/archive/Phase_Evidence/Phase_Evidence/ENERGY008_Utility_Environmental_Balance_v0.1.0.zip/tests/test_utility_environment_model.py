from __future__ import annotations

import csv
import json
import math
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "inputs" / "ENERGY008_UTILITIES_ENV_INPUTS.json"
GENERATED = ROOT / "generated"


class UtilityEnvironmentReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "run_utility_environment_model.py")],
            check=True,
            capture_output=True,
            text=True,
        )
        cls.data = json.loads(INPUT.read_text(encoding="utf-8"))

    def test_annualisation(self):
        ref = self.data["reference_case"]
        self.assertAlmostEqual(
            ref["annual_hours"] * ref["average_load_factor"], 7200.0, places=9
        )
        self.assertAlmostEqual(ref["annual_product_t"], 15000.0, places=9)

    def test_k201_grid_scenario(self):
        ref = self.data["reference_case"]
        k201 = next(x for x in self.data["k201_screening_cases"] if x["scenario"] == "Normal")
        kwh_y = float(k201["motor_input_kW"]) * ref["annual_hours"] * ref["average_load_factor"]
        emissions = kwh_y * self.data["factors"]["cea_grid_weighted_average_kg_co2_kwh"] / 1000.0
        self.assertAlmostEqual(kwh_y, 1956258.3771687793, places=6)
        self.assertAlmostEqual(emissions, 1320.474404588926, places=6)

    def test_carbon_stoichiometric_reference(self):
        s = self.data["stoichiometric_reference_at_50_tpd"]
        self.assertAlmostEqual(
            s["carbon_in_product_tC_d"] * 44.0095 / 12.011,
            s["CO2_equivalent_carbon_in_product_tCO2_d"],
            places=3,
        )
        self.assertAlmostEqual(
            s["CO2_tpd_route_C_A"], s["CO2_equivalent_carbon_in_product_tCO2_d"], places=9
        )

    def test_water_guidance_is_inclusive(self):
        s = self.data["stoichiometric_reference_at_50_tpd"]
        total_low = s["total_process_water_guidance_low_m3_d_route_C_A"]
        di = s["DI_water_guidance_m3_d_route_C_A"]
        self.assertGreaterEqual(total_low, di)
        h2_tpd = s["H2_tpd_route_C_A"]
        self.assertAlmostEqual(total_low, h2_tpd * 18.0, places=3)
        self.assertAlmostEqual(di, h2_tpd * 9.0, places=3)

    def test_three_case_statuses_remain_explicit(self):
        path = GENERATED / "three_case_reference_comparison.csv"
        with path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual([r["case"] for r in rows], ["Base C", "Alternative A", "Alternative B"])
        self.assertTrue(all(r["actual_plant_utility_or_emissions_status"].startswith("BLOCKED") for r in rows))
        self.assertEqual(rows[2]["CO2_feed_tpd_theoretical"], "")
        self.assertEqual(rows[2]["CO_feed_tpd_theoretical"] != "", True)

    def test_no_unexplained_balance_claim(self):
        # The reference package must not claim that a site water balance is closed.
        water_book = ROOT / "ENERGY008_Water_Balance.xlsx"
        self.assertTrue(water_book.exists())
        report = (ROOT / "ENERGY008_Environmental_and_Indian_Compliance_Screen.md").read_text(
            encoding="utf-8"
        )
        self.assertIn("water balance", report.lower())
        self.assertIn("water closure", report.lower())
        self.assertIn("full plant utility closure", report.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
