# Validation Status — ENERGY-008 Prompt 12

**Result:** reference calculations and workbook structure validated; plant-wide utility/environmental acceptance criteria remain open.

## Automated checks

- Reproduction script: executed successfully.
- Unit tests: **6 passed, 0 failed**.
- Post-export workbook import: successful for all three `.xlsx` files.
- Formula-error scan: **0 matches** in each workbook for `#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, `#N/A`.
- Formula spot checks:
  - K-201 annual electricity = 1,956,258.377 kWh/year.
  - K-201 grid comparator = 1,320.474 tCO2/year.
  - K-201 partial specific electricity = 130.417 kWh/t methanol.
  - 50 t/day DI-water guidance = 84.934 m3/day.
  - 50 t/day total water guidance = 169.867–188.742 m3/day inclusive of DI.
  - 50 t/day reaction water = 28.112 t/day.
  - Methanol product carbon = 18.742646 tC/day (18.743 tC/day rounded).
- Formula-linked annualisation:
  - utility comparison calculates annual electricity and grid comparator emissions from the case basis;
  - water capacity envelope annualises guidance using 300 equivalent full-load days/year;
  - GHG scenario uses a dedicated Calculation Inputs sheet for annual hours, load factor, CEA grid factor, MNRE cap and annual product.

## Visual verification

Rendered and visually checked:
- Utility case comparison and service register.
- Water case summary and capacity envelope.
- GHG case summary, Calculation Inputs and Environmental Outputs.
- Waste / wastewater / off-gas register.

## Critical limitations (not a validation failure)

- No actual stream flow/state data from Prompt 8.
- No solved plant duty or utility schedule from Prompt 9.
- No full equipment utility requirements from Prompt 11.
- Actual cooling tower makeup, steam, refrigeration, compressed/instrument air, nitrogen, raw water, boiler feedwater and wastewater-treatment loads remain blank.
- No water, component, carbon, GHG or waste closure is claimed.
- Actual plant Scope 1/2/3 inventory and Green Methanol compliance are not assessable.
- Alternative B gasifier, feedstock and residuals are outside the ideal clean-syngas synthesis-block model.
- Site-specific costs, emissions factors, statutory permit conditions and approvals require selected location and project data.

Blank workbook fields are deliberately retained as unknown/not calculated, not zero.
