# ENERGY-008 Prompt 12 — Utility, Water, Emissions and Waste Package

**Package:** `ENERGY008-UTILITIES-ENV-0.1.0`  
**Prepared:** 1 November 2026  
**Basis:** Prompt 3 Rev 0.1-DRAFT; G3 not frozen; plant site and route gate not approved.

## Included deliverables

- `ENERGY008_Utility_Summary.xlsx`
  - Overview
  - Case Comparison
  - Utility Service Register
  - Capacity Envelope
  - Sources and Methods
- `ENERGY008_Water_Balance.xlsx`
  - Overview
  - Case Water Summary
  - Capacity Envelope
  - PFD Water Stream Register
  - Chemical Stoich Check
  - Closure and Sources
  - Calculation Inputs
- `ENERGY008_Emissions_and_Waste_Register.xlsx`
  - Overview
  - Case GHG Summary
  - GHG Source Register
  - Carbon Reference Balance
  - Waste and Residuals Register
  - Factors and Compliance Triggers
  - Calculation Inputs
- `ENERGY008_Environmental_and_Indian_Compliance_Screen.md`
- `inputs/ENERGY008_UTILITIES_ENV_INPUTS.json`
- `generated/capacity_water_utility_anchors.csv`
- `generated/three_case_reference_comparison.csv`
- `generated/calculation_checks.json`
- `scripts/run_utility_environment_model.py`
- `tests/test_utility_environment_model.py`

## Quantified reference results

At the illustrative 50 t/day methanol component-equivalent basis:

- Route C / Alternative A theoretical CO2 feed: 68.6749 t/day.
- Route C / Alternative A theoretical H2 feed: 9.4371 t/day.
- Electrolysis stoichiometric water: 84.3362 t/day.
- DI water guidance: 84.9337 m3/day, using 9 L/kg H2.
- Total process-water guidance: 169.8675–188.7416 m3/day, using 18–20 L/kg H2 **inclusive of DI water**. Do not add the DI amount again.
- Reaction water: 28.1121 t/day. Net stoichiometric water consumption is 56.2241 t/day; it is not external raw-water demand.
- O2 electrolysis coproduct: 74.8991 t/day.
- K-201 normal compressor screen: 271.7026 kW motor input, 1,956,258 kWh/year at 7,200 equivalent full-load hours, 130.417 kWh/t methanol partial SEC.
- CEA national grid comparator applied to K-201 only: 1,320.474 tCO2/year and 88.032 kgCO2/t methanol. This is not a site-specific emission factor or a full plant Scope 2 inventory.
- MNRE Green Methanol non-biogenic emissions cap: 0.44 kgCO2e/kg methanol over the preceding 12-month average. At 50 t/day, the equivalent threshold is 22 tCO2e/day; actual compliance is not assessable.

## Important calculation boundary

This package is a reference screening ledger, not a closed plant utility, water, carbon, GHG or waste balance. Prompts 8–10 do not provide a solved physical plant material/energy balance; actual process stream flow, composition, state, duty, recycle/purge, and treatment loads remain uncalculated. Only the K-201 power estimate is numerical at equipment level.

Base C and Alternative A share the same ideal stoichiometry. Alternative B covers only ideal clean-CO hydrogenation; gasification, biomass feed, char/tar/ash, gas cleaning and associated utilities/emissions/waste are unmodelled. Blank values mean unknown/not calculated, not zero.

S-309 water reuse is conditional and not credited. Cooling-water circulation is separate from tower make-up, evaporation, drift and blowdown. No heat recovery is credited. No renewable electricity or biogenic/captured carbon is assigned zero emissions by default.

## Reproduction

From this directory:

```bash
python3 scripts/run_utility_environment_model.py
python3 -m unittest discover -s tests -v
```

The script rebuilds the calculation CSV snapshots from the input JSON. The Excel workbooks are formula-driven audit/reporting files generated with `artifact_tool`; their input assumptions and formula logic are recorded in the relevant `Calculation Inputs` and `Sources and Methods` sheets.

## Status

- Utility loads: only K-201 screening estimate quantified; all other loads blocked.
- Water: stoichiometric and design-basis guidance references only; no plant-wide closure.
- Carbon: ideal reaction-block transfer only; actual CO2 utilisation and direct emissions blocked.
- GHG: only K-201 grid comparator calculated; no plant or renewable-electricity footprint claim.
- Waste/off-gas/wastewater: PFD stream mapping and recovery options prepared; actual flow, composition and classification blocked.
- Compliance: current national legal screen; site-specific approvals and applicability remain open.
