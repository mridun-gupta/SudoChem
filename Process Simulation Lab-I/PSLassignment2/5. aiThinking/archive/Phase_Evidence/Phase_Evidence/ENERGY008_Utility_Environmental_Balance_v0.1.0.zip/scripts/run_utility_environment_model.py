#!/usr/bin/env python3
"""
Rebuild the Prompt 12 calculation CSVs from the frozen input snapshot.

This script intentionally rebuilds reference calculations only. It does not
invent missing plant streams, utilities, emissions, waste flows or closure
terms. Excel workbooks are formula-driven presentation/audit files generated
with artifact_tool; this script regenerates their calculation CSV snapshots.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "inputs" / "ENERGY008_UTILITIES_ENV_INPUTS.json"
OUT = ROOT / "generated"


def fnum(value):
    return float(value) if value not in (None, "") else None


def write_csv(path: Path, headers: list[str], rows: list[list[object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def main() -> None:
    data = json.loads(INPUT.read_text(encoding="utf-8"))
    ref = data["reference_case"]
    factors = data["factors"]
    stoich = data["stoichiometric_reference_at_50_tpd"]
    h2_to_meoh = stoich["H2_tpd_route_C_A"] / ref["methanol_tpd"]
    co2_to_meoh = stoich["CO2_tpd_route_C_A"] / ref["methanol_tpd"]
    electrolysis_water_to_meoh = stoich["electrolysis_water_tpd_route_C_A"] / ref["methanol_tpd"]
    reaction_water_to_meoh = stoich["reaction_water_tpd_route_C_A"] / ref["methanol_tpd"]
    di_l_per_kg_h2 = factors["water_guidance_L_per_kg_H2"]["DI"]
    total_low = factors["water_guidance_L_per_kg_H2"]["total_low"]
    total_high = factors["water_guidance_L_per_kg_H2"]["total_high"]
    annual_hours = ref["annual_hours"]
    load_factor = ref["average_load_factor"]
    full_load_hours = annual_hours * load_factor
    annual_product = ref["annual_product_t"]
    grid_ef = factors["cea_grid_weighted_average_kg_co2_kwh"]
    rows = []
    for case in data["operating_cases"]:
        meoh = fnum(case["methanol_tpd"])
        h2_tpd = fnum(case["h2_min_tpd"])
        h2_kgph = fnum(case["h2_kgph"])
        co2_tpd = fnum(case["co2_min_tpd"])
        stoich_water = fnum(case["electrolysis_water_tpd"])
        di_water = fnum(case["di_guidance_m3d"])
        total_low_m3d = fnum(case["total_water_low_m3d"])
        total_high_m3d = fnum(case["total_water_high_m3d"])
        react_water = fnum(case["reaction_water_tpd"])
        o2_tpd = fnum(case["o2_tpd"])
        krow = next(k for k in data["k201_screening_cases"] if k["scenario"] == case["scenario"])
        k_motor = fnum(krow["motor_input_kW"])
        rows.append([
            case["scenario"], meoh, h2_kgph,
            stoich_water, di_water, total_low_m3d, total_high_m3d,
            total_low_m3d - di_water if total_low_m3d is not None else None,
            total_high_m3d - di_water if total_high_m3d is not None else None,
            react_water, stoich_water - react_water,
            di_water * 300 if di_water is not None else None,
            total_low_m3d * 300 if total_low_m3d is not None else None,
            total_high_m3d * 300 if total_high_m3d is not None else None,
        ])
    write_csv(
        OUT / "capacity_water_utility_anchors.csv",
        [
            "scenario", "methanol_tpd", "H2_kgph_theoretical",
            "electrolysis_water_tpd_stoich", "DI_guidance_m3_d",
            "total_water_guidance_low_m3_d_inclusive_of_DI",
            "total_water_guidance_high_m3_d_inclusive_of_DI",
            "guidance_beyond_DI_low_m3_d", "guidance_beyond_DI_high_m3_d",
            "reaction_water_tpd", "net_chemical_water_tpd",
            "annual_DI_guidance_m3_y_at_300_equivalent_days",
            "annual_total_water_guidance_low_m3_y",
            "annual_total_water_guidance_high_m3_y",
        ],
        rows,
    )

    normal_k201 = next(k for k in data["k201_screening_cases"] if k["scenario"] == "Normal")
    k_kw = fnum(normal_k201["motor_input_kW"])
    kwh_y = k_kw * full_load_hours
    co2_tpd = stoich["CO2_tpd_route_C_A"]
    co_tpd = stoich["CO_tpd_route_B"]
    h2_route_b = stoich["H2_tpd_route_B_clean_syngas"]
    product_carbon = stoich["carbon_in_product_tC_d"]
    carbon_eq = stoich["CO2_equivalent_carbon_in_product_tCO2_d"]
    meoh = ref["methanol_tpd"]
    grid_t_y = kwh_y * grid_ef / 1000.0
    grid_kg_t = grid_t_y * 1000.0 / annual_product
    cases = [
        [
            "Base C",
            "Biogenic CO2 + renewable electrolytic H2 (ALK working reference)",
            co2_tpd, "", stoich["H2_tpd_route_C_A"],
            stoich["DI_water_guidance_m3_d_route_C_A"],
            stoich["total_process_water_guidance_low_m3_d_route_C_A"],
            stoich["total_process_water_guidance_high_m3_d_route_C_A"],
            stoich["reaction_water_tpd_route_C_A"], k_kw, grid_t_y, grid_kg_t,
            "BLOCKED_NOT_CALCULATED",
        ],
        [
            "Alternative A",
            "Existing industrial CO2 + renewable electrolytic H2 (ALK reference)",
            co2_tpd, "", stoich["H2_tpd_route_C_A"],
            stoich["DI_water_guidance_m3_d_route_C_A"],
            stoich["total_process_water_guidance_low_m3_d_route_C_A"],
            stoich["total_process_water_guidance_high_m3_d_route_C_A"],
            stoich["reaction_water_tpd_route_C_A"], k_kw, grid_t_y, grid_kg_t,
            "BLOCKED_NOT_CALCULATED",
        ],
        [
            "Alternative B",
            "Biomass residue gasification to syngas; ideal clean-CO hydrogenation block only",
            "", co_tpd, h2_route_b, "", "", "", 0, "", "", "",
            "BLOCKED_GASIFIER_AND_UTILITY_CHAIN_NOT_MODELLED",
        ],
    ]
    write_csv(
        OUT / "three_case_reference_comparison.csv",
        [
            "case", "route", "CO2_feed_tpd_theoretical", "CO_feed_tpd_theoretical",
            "H2_feed_tpd_theoretical", "electrolyser_DI_water_guidance_m3_d",
            "total_water_guidance_low_m3_d_inclusive_of_DI",
            "total_water_guidance_high_m3_d_inclusive_of_DI",
            "reaction_water_tpd", "K201_motor_input_kW_screen",
            "grid_scenario_K201_tCO2_y", "K201_grid_scenario_kgCO2_t_meoh",
            "actual_plant_utility_or_emissions_status",
        ],
        cases,
    )

    # Rebuild a machine-readable checks file using explicit, nonzero tolerances.
    assertions = {
        "full_load_hours": full_load_hours,
        "annual_product_t": annual_product,
        "K201_normal_annual_kWh": kwh_y,
        "K201_grid_comparator_tCO2_y": grid_t_y,
        "K201_grid_comparator_kgCO2_per_t_product": grid_kg_t,
        "CO2_feed_50_tpd_tpd": co2_tpd,
        "product_carbon_tC_day": product_carbon,
        "product_carbon_CO2_equivalent_tpd": carbon_eq,
    }
    (OUT / "calculation_checks.json").write_text(
        json.dumps(assertions, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(assertions, indent=2))


if __name__ == "__main__":
    main()
