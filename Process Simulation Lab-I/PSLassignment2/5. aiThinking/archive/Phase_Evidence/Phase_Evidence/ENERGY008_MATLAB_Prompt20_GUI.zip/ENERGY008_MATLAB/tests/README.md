# Project-level tests

`check_project_static.py` validates the generated project tree, config, manifest, data file hashes and fixture count without MATLAB. The MATLAB source-only smoke test is under `MATLAB/tests/`.
