function run = main(projectRoot,configPath)
%MAIN Verify project inputs, execute supported Prompt 19 reference modules, log and export.
% Physical plant solvers remain disabled by project_config.json engine_policy.
narginchk(2,2);
projectRoot=char(projectRoot); configPath=char(configPath);
if exist(projectRoot,'dir')~=7, error('ENERGY008:ProjectRootMissing','Project root does not exist: %s',projectRoot); end
marker=fullfile(projectRoot,'.energy008-root'); expectedConfig=fullfile(projectRoot,'MATLAB','project_config.json');
if exist(marker,'file')~=2 || isempty(strfind(fileread(marker),'ENERGY008_PROJECT_ID=ENERGY-008')) %#ok<STREMP>
    error('ENERGY008:MarkerInvalid','Project marker is missing or does not identify ENERGY-008.');
end
if exist(configPath,'file')~=2 || ~samePath(configPath,expectedConfig) || ~withinRoot(projectRoot,configPath)
    error('ENERGY008:ConfigPathUnexpected','Configuration must be MATLAB/project_config.json beneath the detected root.');
end
cfg=jsondecode(fileread(configPath));
validateConfig(cfg);
if ~cfg.run_control.calculation_engine_enabled || ~cfg.engine_policy.reference_calculations_enabled
    error('ENERGY008:ReferenceEngineDisabled','Reference calculation engine is disabled by project configuration.');
end
ensureDir(fullfile(projectRoot,'outputs')); ensureDir(fullfile(projectRoot,'logs'));
resultsRoot=resolveRootRelative(projectRoot,cfg.paths.results);
ensureDir(resultsRoot);
if ~withinRoot(projectRoot,resultsRoot), error('ENERGY008:ResultsOutsideProject','MATLAB/results must remain inside project root.'); end
runId=createRunId(fullfile(projectRoot,'outputs'));
runDir=fullfile(projectRoot,'outputs',runId); reportDir=fullfile(resultsRoot,runId);
ensureDir(runDir);
if exist(reportDir,'dir')==7 || exist(reportDir,'file')==2
    error('ENERGY008:ResultsDirectoryCollision','Refusing to reuse or overwrite results directory: %s',reportDir);
end
ensureDir(reportDir);
run=struct('project_id','ENERGY-008','project_root',projectRoot,'run_id',runId, ...
 'started_local',datestr(now,'yyyy-mm-ddTHH:MM:SS'),'matlab_version',version,'software_version',version, ...
 'computer',computer,'status','STARTUP_IN_PROGRESS','calculation_status','NOT_RUN', ...
 'data_integrity','NOT_VERIFIED','run_directory',runDir,'report_directory',reportDir, ...
 'log_json',fullfile(projectRoot,'logs',[runId '.json']),'log_text',fullfile(projectRoot,'logs',[runId '.log']), ...
 'warnings',{{}},'errors',{{}},'configuration',cfg);
try
    run.config_path=configPath; run.config_sha256=sha256_file(configPath);
    manifestPath=resolveRootRelative(projectRoot,cfg.paths.data_manifest);
    if ~withinRoot(projectRoot,manifestPath) || exist(manifestPath,'file')~=2
        error('ENERGY008:ManifestMissing','Declared project data manifest is missing or outside project root.');
    end
    run.manifest_path=manifestPath; run.manifest_sha256=sha256_file(manifestPath);
    manifest=jsondecode(fileread(manifestPath));
    if ~isfield(manifest,'project_id') || ~strcmp(char(manifest.project_id),cfg.project_id)
        error('ENERGY008:ManifestProjectMismatch','Data manifest project_id does not match project configuration.');
    end
    roots=cellstrSafe(cfg.paths.data_roots); manifestRoots=cellstrSafe(manifest.discovery_policy.allowed_roots);
    if ~isequal(sort(roots),sort(manifestRoots))
        error('ENERGY008:DataRootPolicyMismatch','project_config.json and data_manifest.json allowed roots do not match exactly.');
    end
    formats=[cellstrSafe(cfg.formats.runtime_data),cellstrSafe(cfg.formats.project_documentation), ...
        cellstrSafe(cfg.formats.flowcharts),cellstrSafe(cfg.formats.project_source_assets)];
    [catalog,discoveryWarnings]=resolve_project_data(projectRoot,manifest,roots,formats,cfg.run_control.verify_sha256);
    run.resolved_data=catalog; run.warnings=[run.warnings,discoveryWarnings]; run.data_integrity='SHA256_VERIFIED';
    modelInput=load_model_inputs(projectRoot,cfg,runId);
    modelInput.source_hashes=struct('configuration',run.config_sha256,'manifest',run.manifest_sha256);
    options=struct('run_id',runId,'material_tolerance',1e-8,'allow_reference_only',true, ...
        'allow_screening_only',true,'allow_solver_execution',false,'overwrite_outputs',false);
    R=struct();
    R.input=input_validation(modelInput,struct('scope','default_case'),options);
    if strcmp(R.input.status,'FAILED'), error('ENERGY008:InputValidationFailed','Default-case input validation failed; inspect diagnostics in the run log.'); end
    R.properties=property_models(modelInput,struct('property_request','all_benchmark'),options);
    R.material=material_balance(modelInput,struct('case_id',modelInput.case_data.case_id),options);
    if any(strcmp(R.material.status,{'BLOCKED','FAILED'}))
        error('ENERGY008:ReferenceMaterialBalanceFailed','Reference stoichiometric material calculation did not complete.');
    end
    R.energy=energy_balance(modelInput,struct('material_result',R.material,'property_result',R.properties),options);
    R.entropy=entropy_exergy(modelInput,struct(),options);
    R.reactor=reactor_calculation(modelInput,struct(),options);
    R.recycle=recycle_solver(modelInput,struct(),options);
    R.equipment=equipment_sizing(modelInput,struct('energy_result',R.energy,'material_result',R.material),options);
    R.utilities=utilities_model(modelInput,struct('material_result',R.material),options);
    R.control=control_logic(modelInput,struct('material_result',R.material),options);
    R.environmental=environmental_kpis(modelInput,struct(),options);
    R.economics=economics(modelInput,struct(),options);
    R.scenarios=scenario_runner(modelInput,struct('control_result',R.control),options);
    R.sensitivity=sensitivity_optimisation(modelInput,struct(),options);
    R.validation=validation_checks(modelInput,struct('material_result',R.material,'energy_result',R.energy, ...
        'entropy_result',R.entropy,'utilities_result',R.utilities,'property_result',R.properties, ...
        'equipment_result',R.equipment),options);
    if ~strcmp(R.validation.status,'PASS_WITH_BLOCKED_PHYSICAL_GATES')
        error('ENERGY008:FixtureRegressionFailed','Prompt 17 fixture or semantic gate checks failed.');
    end
    R.status='REFERENCE_ENGINE_EXECUTED_WITH_EXPLICIT_PHYSICAL_BLOCKERS';
    R.reporting=reporting_plots(modelInput,struct('results',R,'output_directory',reportDir),options);
    if strcmp(R.reporting.status,'FAILED')
        error('ENERGY008:ReportingFailed','Run result export failed; inspect reporting module diagnostics.');
    end
    run.engine_summary=moduleSummary(R);
    run.engine_output_directory=reportDir;
    run.fixture_validation_status=R.validation.status;
    run.fixture_validation_count=R.validation.value.test_count;
    run.calculation_status='REFERENCE_RUN_COMPLETE_WITH_PHYSICAL_BLOCKERS';
    run.status='COMPLETED_WITH_BLOCKED_PHYSICAL_CALCULATIONS';
    run.warnings=[run.warnings,{'Only reference and bounded screening calculations were executed. The physical process model is not validated; Prompt 21 remains required.'}];
    run.finished_local=datestr(now,'yyyy-mm-ddTHH:MM:SS');
    writeRunLog(run,run.log_json,run.log_text);
catch ME
    run.status='RUN_FAILED'; run.calculation_status='FAILED'; run.finished_local=datestr(now,'yyyy-mm-ddTHH:MM:SS');
    run.errors={struct('identifier',ME.identifier,'message',ME.message)};
    try, writeRunLog(run,run.log_json,run.log_text); catch logME, warning('ENERGY008:LogWriteFailure','Could not write failure log: %s',logME.message); end
    rethrow(ME);
end
end
function validateConfig(cfg)
required={'project_id','project_version','config_schema_version','paths','formats','run_control','engine_policy','toolbox_policy'};
for k=1:numel(required)
    if ~isfield(cfg,required{k}), error('ENERGY008:ConfigFieldMissing','project_config.json is missing %s.',required{k}); end
end
if ~strcmp(char(cfg.project_id),'ENERGY-008'), error('ENERGY008:ConfigProjectMismatch','project_id must be ENERGY-008.'); end
if ~strcmp(char(cfg.config_schema_version),'ENERGY008-PROJECT-CONFIG-0.1.0'), error('ENERGY008:ConfigSchemaUnsupported','Unsupported config schema version.'); end
if ~isfield(cfg.paths,'results') || ~strcmp(char(cfg.paths.results),'MATLAB/results')
    error('ENERGY008:ResultsPathPolicy','paths.results must be MATLAB/results.');
end
if ~isfield(cfg.paths,'data_roots') || isempty(cfg.paths.data_roots) || ...
        ~any(strcmp(cellstrSafe(cfg.paths.data_roots),'MATLAB/data'))
    error('ENERGY008:DataRootPolicy','MATLAB/data must be an explicitly declared data root for versioned engine inputs.');
end
if cfg.run_control.overwrite_outputs~=false || cfg.run_control.allow_solver_execution~=false
    error('ENERGY008:ExecutionPolicyInvalid','Overwrite and physical solver execution must remain disabled.');
end
physical={'physical_flowsheet_solver_enabled','plant_recycle_solver_enabled','pfr_kinetic_solver_enabled', ...
 'pr78_flash_enabled','meoh_water_vle_enabled','dynamic_control_simulation_enabled','economic_model_enabled'};
for k=1:numel(physical)
    if ~isfield(cfg.engine_policy,physical{k}) || cfg.engine_policy.(physical{k})~=false
        error('ENERGY008:PhysicalSolverGateInvalid','Physical solver gate %s must remain false.',physical{k});
    end
end
end
function s=moduleSummary(R)
n=fieldnames(R); s=struct();
for k=1:numel(n)
    x=R.(n{k}); if isstruct(x)&&isfield(x,'status')&&ischar(x.status)
        s.(n{k})=struct('status',x.status,'failure_codes',{x.failure_codes});
    end
end
end
function values=cellstrSafe(v)
if iscell(v), values=cellfun(@char,v,'UniformOutput',false); elseif isstring(v), values=cellstr(v); elseif ischar(v), values={v}; else, error('ENERGY008:ConfigTypeInvalid','Expected text list in configuration.'); end
end
function p=resolveRootRelative(root,rel)
rel=strrep(char(rel),char(92),'/'); parts=strsplit(rel,'/');
if isempty(rel)||rel(1)=='/'||~isempty(regexp(rel,'^[A-Za-z]:','once'))||any(strcmp(parts,'..'))
    error('ENERGY008:UnsafeProjectPath','Project-relative path contains an absolute path or parent traversal: %s',rel);
end
p=fullfile(root,rel);
end
function ensureDir(p)
if exist(p,'dir')~=7, [ok,msg]=mkdir(p); if ~ok, error('ENERGY008:DirectoryCreateFailed','Could not create %s: %s',p,msg); end, end
end
function tf=withinRoot(root,candidate)
[ok1,a]=fileattrib(root); [ok2,b]=fileattrib(candidate); if ok1,root=char(a.Name);end; if ok2,candidate=char(b.Name);end
prefix=[root filesep]; if ispc,tf=strcmpi(candidate,root)||strncmpi(candidate,prefix,numel(prefix));else,tf=strcmp(candidate,root)||strncmp(candidate,prefix,numel(prefix));end
end
function tf=samePath(a,b)
[ok1,x]=fileattrib(a); [ok2,y]=fileattrib(b); if ok1,a=char(x.Name);end;if ok2,b=char(y.Name);end
if ispc,tf=strcmpi(char(a),char(b));else,tf=strcmp(char(a),char(b));end
end
function id=createRunId(folder)
stamp=datestr(now,'yyyymmdd_HHMMSS');
for k=1:100
    token=regexprep(tempname,'[^A-Za-z0-9]',''); token=token(max(1,end-7):end);
    id=['run_' stamp '_' token]; if exist(fullfile(folder,id),'dir')~=7, return; end
end
error('ENERGY008:RunIdExhausted','Could not allocate unique run ID.');
end
function writeRunLog(run,jsonPath,textPath)
if exist(jsonPath,'file')==2||exist(textPath,'file')==2, error('ENERGY008:LogCollision','Refusing to overwrite an existing run log.'); end
f=fopen(jsonPath,'w'); if f<0, error('ENERGY008:LogWriteFailed','Cannot write run JSON log: %s',jsonPath); end
cl=onCleanup(@()fclose(f)); fwrite(f,jsonencode(run),'char'); fprintf(f,'\n'); clear cl;
f=fopen(textPath,'w'); if f<0, error('ENERGY008:LogWriteFailed','Cannot write run text log: %s',textPath); end
cl=onCleanup(@()fclose(f));
fprintf(f,'ENERGY-008 RUN LOG\nRun ID: %s\nStatus: %s\nCalculation status: %s\nProject root: %s\nMATLAB: %s\nStarted: %s\nFinished: %s\nData integrity: %s\n', ...
    run.run_id,run.status,run.calculation_status,run.project_root,run.matlab_version,run.started_local,run.finished_local,run.data_integrity);
if isfield(run,'config_sha256'), fprintf(f,'CONFIG SHA256: %s\n',run.config_sha256); end
if isfield(run,'manifest_sha256'), fprintf(f,'MANIFEST SHA256: %s\n',run.manifest_sha256); end
if isfield(run,'resolved_data')
    for k=1:numel(run.resolved_data)
        fprintf(f,'DATA %s | %s | SHA256 %s\n',run.resolved_data(k).dataset_id,run.resolved_data(k).logical_name,run.resolved_data(k).sha256);
    end
end
for k=1:numel(run.warnings), fprintf(f,'WARNING: %s\n',run.warnings{k}); end
for k=1:numel(run.errors), fprintf(f,'ERROR %s: %s\n',run.errors{k}.identifier,run.errors{k}.message); end
clear cl;
end
