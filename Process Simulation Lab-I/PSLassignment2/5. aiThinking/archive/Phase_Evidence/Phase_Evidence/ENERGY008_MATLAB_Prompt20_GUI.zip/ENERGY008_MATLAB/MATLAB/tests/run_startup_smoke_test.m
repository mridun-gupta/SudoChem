% Prompt 19 startup/runtime smoke test. Run this script from the MATLAB Editor.
ENERGY008_SMOKE_ENTRY=mfilename('fullpath');
if isempty(ENERGY008_SMOKE_ENTRY), error('ENERGY008:SmokeEntryMissing','Cannot determine smoke-test path.'); end
ENERGY008_SMOKE_DIR=fileparts(ENERGY008_SMOKE_ENTRY);
ENERGY008_SMOKE_ROOT=fileparts(fileparts(ENERGY008_SMOKE_DIR));
ENERGY008_SMOKE_START=fullfile(ENERGY008_SMOKE_ROOT,'MATLAB','START_HERE.m');
if exist(ENERGY008_SMOKE_START,'file')~=2, error('ENERGY008:SmokeStartMissing','START_HERE.m not found.'); end
ENERGY008_SMOKE_ORIGINAL=pwd;
cd(tempdir);
try
    run(ENERGY008_SMOKE_START);
    assert(strcmp(ENERGY008_RUN.status,'COMPLETED_WITH_BLOCKED_PHYSICAL_CALCULATIONS'));
    assert(strcmp(ENERGY008_RUN.calculation_status,'REFERENCE_RUN_COMPLETE_WITH_PHYSICAL_BLOCKERS'));
    assert(strcmp(ENERGY008_RUN.fixture_validation_status,'PASS_WITH_BLOCKED_PHYSICAL_GATES'));
catch ME
    cd(ENERGY008_SMOKE_ORIGINAL); rethrow(ME);
end
cd(ENERGY008_SMOKE_ORIGINAL);
fprintf('ENERGY-008 Prompt 19 startup smoke test PASS.\n');
