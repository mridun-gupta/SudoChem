# ENERGY-008 MATLAB Engine and GUI

The `MATLAB/` folder contains the Prompt 19 calculation engine and Prompt 20 programmatic GUI.

## Launch the engineering GUI

From MATLAB's Current Folder panel, navigate into this `MATLAB/` directory, then run:

```matlab
app = run_gui;
```

The launcher resolves the project root from `run_gui.m` and `.energy008-root`, verifies the configured project identity, and adds only the controlled `MATLAB/` engine and `MATLAB/gui/` folders. The GUI is a separate presentation/input layer; all engineering calculations remain in engine modules.

## Engine startup and tests

The non-GUI reference workflow starts from `START_HERE.m`. After the startup script completes, use the root-level test wrapper:

```matlab
report = run_prompt19_tests(ENERGY008_PROJECT_ROOT);
```

For the startup/relocation smoke test, execute the controlled test script by its full project-relative path:

```matlab
run(fullfile(ENERGY008_PROJECT_ROOT, 'MATLAB', 'tests', 'run_startup_smoke_test.m'));
```

The root-level test wrapper temporarily adds only `MATLAB/tests/` and restores the original path immediately after the suite. Normal startup does not add the tests folder.

## Model and GUI boundaries

Prompt 19 implements the ideal stoichiometric reference calculation, selected pure-component property reference correlations, standard-state reaction enthalpy references, bounded equipment screening, DB-059 shortfall arithmetic, scenario status propagation, source-gated environmental KPIs and source-gated CAPEX/OPEX/LCOM equations. Missing process data do not become zero.

Prompt 20 adds tabs for Design Basis, Streams, Operating Conditions, Process Model, Balances, Equipment, Utilities & Environment, Economics, Automation & Control, Sensitivity & Optimisation, and Reports. The GUI uses the Prompt 19 modules and does not duplicate process equations in callbacks. The Streams tab shows the stoichiometric component/ledger reference only, not all 55 physical PFD stream states. The Automation & Control tab is read-only and does not connect to a live DCS, BPCS, PLC, SIS, ESD, FGS or field device.

Physical PFR kinetics, PR78 flash, methanol-water VLE, physical S-209 recycle/S-207 purge, actual utilities, plant energy/entropy/exergy closure, environmental MRV, and project economics remain blocked where validated inputs are missing. A reference fixture pass is not physical process validation. Prompt 21 independent verification and validation remain mandatory.

## Runtime caveat

MATLAB and GNU Octave were unavailable during this build. MATLAB release compatibility, UI component behavior, engine integration, actual plotting/export, repeated-run behavior and screenshot capture have not been runtime tested. The minimum MATLAB release and toolbox availability remain unverified. SHA-256 integrity verification requires an enabled MATLAB JVM. See `docs/GUI_User_Guide.md`, `docs/RUNTIME_TEST_STATUS.md` and `docs/Prompt21_GUI_Handoff.md`.
